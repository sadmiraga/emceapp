<!-- Very little is needed to make a happy life. - Marcus Antoninus -->

<div class="push"></div>

<footer id="footer">

    <div class="social-media-container">
        <a href="www.facebook.com"><i class="social-icons fa fa-facebook"></i></a>
        <a href="www.facebook.com"><i class="social-icons fa fa-instagram"></i></a>
        <a href="www.facebook.com"><i class="social-icons fa fa-twitter"></i></a>
    </div>


    <p class="author">
        <span>Created by: <br> <a href="http://sadmir-hasanic.com/"> Sadmir Hasanić </a> </span>
    </p>

    <a id="adminitracija" href="/admin-redirect">Administracija</a>

</footer>
