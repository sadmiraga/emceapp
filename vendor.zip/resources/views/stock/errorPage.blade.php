<img src="/images/error_image.png" width="50%"
    style="height:fit-content;margin-left:25%;margin-right:25%;margin-top:25%;">
