<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">turniri</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <!-- add new tournament -->
    <div class="events-header">
        <div onclick="location.href='/dodaj-turnir'" class="add-new-event">
            <i class="fas fa-plus"></i>
        </div>
    </div>


    <div class="events-container">

        <?php $__currentLoopData = $tournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div onclick="location.href='/turnir/<?php echo e($tournament->id); ?>'" class="card event-card" style="width: 50%;">
                <img class="card-img-top event-cover-image" src="/images/tournaments/covers/<?php echo e($tournament->image); ?>"
                    alt="Card image cap">
                <div class="card-body">

                    <!-- NAME -->
                    <div class="centered-header">
                        <p><?php echo e($tournament->name); ?></p>
                    </div>

                </div>
            </div>



        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/tournaments/tournamentsIndex.blade.php ENDPATH**/ ?>