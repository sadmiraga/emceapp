    <!-- success message -->
    <?php if(session()->has('successMessage')): ?>
        <div style="text-align:center;" class="alert alert-success">
            <?php echo e(session()->get('successMessage')); ?>

        </div>
    <?php endif; ?>

    <!-- error message -->
    <?php if(session()->has('errorMessage')): ?>
        <div style="text-align:center;" class="alert alert-danger">
            <?php echo e(session()->get('errorMessage')); ?>

        </div>
    <?php endif; ?>
<?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/components/alert-component.blade.php ENDPATH**/ ?>