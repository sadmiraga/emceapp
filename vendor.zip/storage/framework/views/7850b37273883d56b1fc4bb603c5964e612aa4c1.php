<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- CUSTOM JS -->
    <script src="<?php echo e(asset('js/admin/alert.js')); ?>" defer></script>


    <!-- FLICKITY -->
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
    <script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- ajax and shit -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>



<body>

    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@300;500&display=swap" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <div class="menu-header-container">
        <div class="menu-header">
            <img onclick="location.href='/'" id="menu-logo" src="/images/logos/emceLogo.jpg" alt="emce plac">
        </div>

        <div class="eighty" style="margin-top:5%;">
            <?php if (isset($component)) { $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlertComponent::class, []); ?>
<?php $component->withName('alert-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8)): ?>
<?php $component = $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8; ?>
<?php unset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

        <h2 class="thin-header">Prijava na turnir</h2>

        <div class="tournament-application-container">

            <?php echo Form::open(['url' => '/prijavi-ekipi-exe', 'method' => 'post', 'enctype' => 'multipart/form-data', 'files' => 'true']); ?>

            <?php echo csrf_field(); ?>

            <input class="form-control custom-tournament-input" placeholder="Naziv ekipe" name="teamName" required>

            <input class="form-control custom-tournament-input" placeholder="Član 1 (ime in priimek)" name="member1"
                required>

            <input class="form-control custom-tournament-input" placeholder="Član 2 (ime in priimek)" name="member2"
                required>

            <input class="form-control custom-tournament-input" placeholder="Kontaktna številka" name="number" required>

            <input type="hidden" value="<?php echo e($tournament->id); ?>" name="tournamentID">

            <input type="submit" value="PRIJAVA" class="btn btn-success tournament-button">

            <?php echo Form::close(); ?>


        </div>

        <h2 class="thin-header prize-header" style="margin-bottom: 0px !important;">nagrada</h2>
        <h4 class="below-header"><?php echo e($tournament->prize); ?></h4>

        <div class="prize-container">
            <img class="prize-image" src="/images/tournaments/prizes/<?php echo e($tournament->prizeImage); ?>">
        </div>



        <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/guest/newTeam.blade.php ENDPATH**/ ?>