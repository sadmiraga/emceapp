<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header"><?php echo e('Uredi ' . $categoryName . ' meni'); ?></h2>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid">

        <div class="row" id="menus-container">

            <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" id="menu-drink">
                    <div class="card-body">

                        <div onclick="location.href='/spremeni-pozicijo/down/<?php echo e($drink->drink_id); ?>/<?php echo e($drink->category_id); ?>'"
                            id="down-arrows" class="arrows-container">
                            <i class="fa fa-arrow-down"></i>
                        </div>

                        <span class="menu-drink-name"><?php echo e($drink->name); ?></span>


                        <div onclick="location.href='/spremeni-pozicijo/up/<?php echo e($drink->drink_id); ?>/<?php echo e($drink->category_id); ?>'"
                            id="up-arrows" class="arrows-container">
                            <i class="fa fa-arrow-up"></i>
                        </div>


                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.adminLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/menu/editMenu.blade.php ENDPATH**/ ?>