<?php $__env->startSection('content'); ?>

    <div class="card">

        <!-- head -->
        <div class="card-header">
            <?php echo e("Urejanje '" . $drink->name . "'"); ?>

        </div>


        <?php echo Form::open(['url' => '/uredi-pijaco-exe', 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php echo csrf_field(); ?>
        <div class="card-body">

            <input type="hidden" value="<?php echo e($drink->id); ?>" name="drinkID">


            <!-- DRINK NAME -->
            <div class="form-group">
                <div class="form-input">
                    <input required class="form-control" name="drinkName" placeholder="Vnesite ime pijače"
                        value="<?php echo e($drink->name); ?>">
                </div>
            </div>


            <!-- DRINK PRICE -->
            <div class="input-group mb-3">
                <input required type="number" step=".01" name="drinkPrice" class="form-control"
                    value="<?php echo e($drink->price); ?>" placeholder="Vnesite ceno pijače">
                <div class="input-group-append">
                    <span class="input-group-text">€</span>
                </div>
            </div>

            <!-- DRINK CATEGORY -->
            <div class="form-group">
                <select class="form-control" name="category_id" aria-label="Default select example">
                    <option value="0" selected disabled>Izberi kategorijo pijače</option>
                    <?php $__currentLoopData = $drinkCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($drink->category_id == $drinkCategory->id): ?>
                            <option selected value="<?php echo e($drinkCategory->id); ?>"> <?php echo e($drinkCategory->categoryName); ?>

                            </option>
                        <?php else: ?>
                            <option value="<?php echo e($drinkCategory->id); ?>"> <?php echo e($drinkCategory->categoryName); ?> </option>
                        <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- DRINK WEIGHTABLE CHECKBOX -->
            <div class="form-group">
                <div class="custom-control custom-switch">

                    <?php if(is_null($drink->packing_weight)): ?>
                        <input type="checkbox" id="weightableCheckbox" name="weightableCheckbox"
                            class="custom-control-input" onchange="enableWeight();">
                    <?php else: ?>
                        <input type="checkbox" checked id="weightableCheckbox" name="weightableCheckbox"
                            class="custom-control-input" onchange="enableWeight();">
                    <?php endif; ?>

                    <label class="custom-control-label" for="weightableCheckbox">Za tehtati</label>
                </div>
            </div>


            <!-- DRINK PACKING WEIGHT -->
            <?php if(is_null($drink->packing_weight)): ?>
                <div style="display:none;" class="input-group mb-3" id="drink-packing-weight-div">
                <?php else: ?>
                    <div class="input-group mb-3" id="drink-packing-weight-div">
            <?php endif; ?>

            <input type="number" step=".01" name="packingWeight" id="packingWeight" value="<?php echo e($drink->packing_weight); ?>"
                class="form-control" placeholder="Vnesite težo embelaže">

            <div class="input-group-append">
                <span class="input-group-text">Kg</span>
            </div>

        </div>





        <!-- SUBMIT -->
        <div class="form-group">
            <button class="btn btn-success" type="submit">Shrani</button>
        </div>
    </div>
    <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.adminLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/drinks/editDrink.blade.php ENDPATH**/ ?>