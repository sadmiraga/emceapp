<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">pijace</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container" id="drinks-index-container">

        <!-- SEARCH -->
        <div class="form-group new-drink-form">
            <div onclick="location.href='/dodaj-pijaco'" class="add-new-drink-button">
                <i class="fas fa-plus"></i>
            </div>
            <input id="myInput" class="form-control" type="text" placeholder="Iskanje..">
        </div>

        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">Ime</th>
                        <th scope="col">Cena</th>
                        <th scope="col">Kategorija</th>
                        <th scope="col">Embelaža </th>
                        <th scope="col"># </th>

                    </tr>
                </thead>
                <tbody id="myTable">
                    <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($drink->name); ?></td>
                            <td><?php echo e($drink->price . '€'); ?></td>
                            <td><?php echo e($drink->categoryName); ?></td>

                            <?php if(is_null($drink->packing_weight)): ?>
                                <td><?php echo e('#'); ?></td>
                            <?php else: ?>
                                <td><?php echo e($drink->packing_weight . ' Kg'); ?></td>
                            <?php endif; ?>

                            <td>
                                <!-- EDIT -->
                                <div onclick="location.href='/uredi-pijaco/<?php echo e($drink->id); ?>'" class="add-new-event">
                                    <i class="fas fa-cog"></i>
                                </div>


                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>



    </div> <!-- end CONTAINER -->


    <!-- live search script -->
    <script>
        $(document).ready(function() {
            $("#myInput").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $("#myTable tr").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.adminLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/drinks/drinksIndex.blade.php ENDPATH**/ ?>