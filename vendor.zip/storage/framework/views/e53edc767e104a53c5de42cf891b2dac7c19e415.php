<?php $__env->startSection('content'); ?>


    <div class="container-fluid">

        <div class="row" id="menus-container">

            <?php $__currentLoopData = $drinkCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drinkCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div onclick="location.href='/uredi-meni/<?php echo e($drinkCategory->id); ?>'" class="card" id="menu-card">
                    <div class="card-body">
                        <?php echo e($drinkCategory->categoryName . ' Meni'); ?>


                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.adminLayout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/menu/privateIndex.blade.php ENDPATH**/ ?>