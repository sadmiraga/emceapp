<?php $__env->startSection('content'); ?>



    <?php if($drinks->count() > 0): ?>
        <div class="card complete-stocktaking-card">
            <div class="card-header complete-stocktaking-header">
                Za naslenje pijače niste vnesli vse vrednosti, v popis bo se avtomatsko vnesla vrednost 0 za vse
                vrednosti pijac ki jih niste vnesli.
            </div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item stocktaking-uncounted"><?php echo e($drink->drinkName); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item stocktaking-actions">
                    <button onclick="location.href='/aktivni-popis'" class="btn btn-danger card-button">Prekliči oddajo
                        popisa</button>
                    <button onclick="location.href='/potrdi-popis'" class="btn btn-success card-button">Potrdi oddajo
                        popisa</button>
                </li>
            </ul>
        </div>
    <?php else: ?>
        <div style="display: flex;justify-content: center; margin-top: 10%;">
            <button onclick=" location.href='/potrdi-popis'" class="  btn btn-success">Potrdi oddajo
                popisa</button>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/bartender/completeStocktaking.blade.php ENDPATH**/ ?>