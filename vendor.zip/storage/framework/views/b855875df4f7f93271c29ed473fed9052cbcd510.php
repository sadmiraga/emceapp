<?php $__env->startSection('content'); ?>


    <div class="tournament-buttons">
        <button onclick="location.href='/zakljuci-prijave/<?php echo e($tournament->id); ?>'" class="btn btn-warning">Zakljuci
            prijave</button>
        <button class="btn btn-danger">Zakljuci turnir</button>
    </div>

    <!-- ALERT MESSAGES -->
    <?php if (isset($component)) { $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlertComponent::class, []); ?>
<?php $component->withName('alert-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8)): ?>
<?php $component = $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8; ?>
<?php unset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <h2 class="thin-header">Ekipe</h2>


    <div id="accordion">

        <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card team-card">

                <!-- header -->
                <a class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapse<?php echo e($loop->iteration); ?>"
                    aria-expanded="false" aria-controls="collapse<?php echo e($loop->iteration); ?>">
                    <div>
                        <h5 class="teamName">
                            <?php echo e($team->teamName); ?>

                        </h5>
                    </div>
                </a>

                <!-- collapse body -->
                <div id="collapse<?php echo e($loop->iteration); ?>" class="collapse" aria-labelledby="headingTwo"
                    data-parent="#accordion">
                    <div class="card-body">
                        <p class="team-element"><?php echo e($team->teamName); ?></p>
                        <p class="team-element"><?php echo e($team->member_1); ?></p>
                        <p class="team-element"><?php echo e($team->member_2); ?></p>
                        <p class="team-element"><a
                                href="tel:<?php echo e($team->contact_number); ?>"><?php echo e($team->contact_number); ?></a></p>
                        <button onclick="location.href=' /odjavi-ekipo/<?php echo e($team->id); ?>'"
                            class="btn delete-team-button">Odjavi Ekipo</button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/tournaments/tournamentDetails.blade.php ENDPATH**/ ?>