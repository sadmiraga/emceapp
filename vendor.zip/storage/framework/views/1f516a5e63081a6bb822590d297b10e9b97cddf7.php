<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- CUSTOM JS -->
    <script src="<?php echo e(asset('js/admin/sidebar.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/admin/drinks.js')); ?>" defer></script>
    <?php echo $__env->yieldContent('js'); ?>


    <!-- FLICKITY -->
    <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
    <script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- ajax and shit -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>



<body>

    <link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hind+Vadodara:wght@300;500&display=swap" rel="stylesheet">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <div class="menu-header-container">
        <div class="menu-header">
            <img onclick="location.href='/'" id="menu-logo" src="/images/logos/emceLogo.jpg" alt="emce plac">
        </div>
    </div>




    <div class="event-header-image" style='background-image: url("/images/events/<?php echo e($event->eventPicture); ?>");'>
    </div>


    <div class="centered-header event-heading">
        <p><?php echo e($event->eventName); ?></p>
    </div>

    <!-- DATE -->
    <div class="row event-row-info guest-event-info-row">
        <p><i class="far fa-calendar-alt"></i> Datum</p>
        <p><?php echo e($event->eventDate); ?></p>
    </div>

    <!-- TIME -->
    <div class="row event-row-info guest-event-info-row">
        <p><i class="far fa-clock"></i> Čas</p>
        <p><?php echo e($event->eventTime); ?></p>
    </div>

    <!-- LOCATION -->
    <div class="row event-row-info guest-event-info-row">
        <p><i class="fas fa-map-marker-alt"></i> Lokacija</p>
        <p><?php echo e($event->eventLocation); ?></p>
    </div>

    <!-- TICKET -->
    <div class="row event-row-info guest-event-info-row">
        <p><i class="fas fa-ticket-alt"></i> Vstopnina</p>
        <p><?php echo e($event->ticketPrice . '€'); ?></p>
    </div>



    <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('Footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/guest/viewEvent.blade.php ENDPATH**/ ?>