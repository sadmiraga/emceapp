<?php $__env->startSection('content'); ?>


    <div class="table-responsive ">
        <table class="table">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Kelner</th>
                    <th scope="col">Zacetek</th>
                    <th scope="col">Konec</th>
                    <th scope="col">#</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $stocktakings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stocktaking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($stocktaking->completed == true): ?>
                        <tr class="stocktaking-table-row" onclick="location.href='/ogled-popisa/<?php echo e($stocktaking->id); ?>'">
                        <?php else: ?>
                        <tr class="stocktaking-table-row unclickable">
                    <?php endif; ?>

                    <!-- bartender -->
                    <td><?php echo e($stocktaking->firstName . ' ' . $stocktaking->lastName); ?></td>

                    <!-- stocktaking start -->
                    <td class="stocktaking-timestamp">
                        <p class="formated-timestamp"><?php echo e(date('d-m-Y', strtotime($stocktaking->start))); ?></p>
                        <p class="formated-timestamp"><?php echo e(date('H:i', strtotime($stocktaking->start))); ?> </p>
                    </td>

                    <!-- stocktaking  end -->
                    <td>
                        <p class="formated-timestamp"><?php echo e(date('d-m-Y', strtotime($stocktaking->end))); ?></p>
                        <p class="formated-timestamp"><?php echo e(date('H:i', strtotime($stocktaking->end))); ?> </p>
                    </td>

                    <!-- completed  -->
                    <?php if($stocktaking->completed == true): ?>

                        <td><i class="fa fa-check-circle"></i></td>
                    <?php elseif($stocktaking->completed == false): ?>
                        <td><i class="fas fa-user-clock"></i></td>

                    <?php endif; ?>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/director/stocktakingArchive.blade.php ENDPATH**/ ?>