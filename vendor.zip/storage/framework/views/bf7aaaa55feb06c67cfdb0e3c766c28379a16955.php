<?php $__env->startSection('content'); ?>




    <div class="card custom-user-card">

        <!-- head -->
        <div class="card-header">
            <?php echo e($user->firstName . ' ' . $user->lastName); ?>

        </div>


        <?php echo Form::open(['url' => '/editUserExe', 'method' => 'post', 'enctype' => 'multipart/form-data']); ?>

        <?php echo csrf_field(); ?>
        <!-- body -->
        <div class="card-body">
            <div class="form-group">
                <select class="form-control" name="type_id" id="typeID" aria-label="Default select example">
                    <?php $__currentLoopData = $userTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php if($userType->id == $user->type_id): ?> selected <?php endif; ?> value="<?php echo e($userType->id); ?>"><?php echo e($userType->userType); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <div class="type-description">
                    <p id="description-container">
                        <?php echo e($selectedUserType->description); ?>

                    </p>
                </div>
            </div>

            <input type="hidden" value="<?php echo e($user->id); ?>" name="userID">

            <!-- submit -->
            <div class="form-group">
                <button class="btn btn-success fullwidth" type="submit">
                    <i class="fas fa-check"></i>
                </button>
            </div>
        </div>
        <?php echo Form::close(); ?>

    </div>


    <script>
        //dynamic oblika field
        $('#typeID').change(function() {
            $("#description-container").empty();

            var typeID = $(this).val();

            $.ajax({
                type: "GET",
                url: "<?php echo e(url('getDescription')); ?>?typeID=" + typeID,
                success: function(res) {
                    if (res) {

                        $.each(res, function(key, value) {

                            $("#description-container").append(value);
                        });

                    } else {
                        $("#description-container").empty();
                    }
                }
            });

        });
    </script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/editUser.blade.php ENDPATH**/ ?>