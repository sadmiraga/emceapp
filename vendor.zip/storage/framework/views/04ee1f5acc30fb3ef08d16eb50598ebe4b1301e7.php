<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">dogodki</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="events-header">
        <div onclick="location.href='/dodaj-dogodek'" class="add-new-event">
            <i class="fas fa-plus"></i>
        </div>
    </div>

    <div class="events-container">

        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card event-card" style="width: 50%;">
                <img class="card-img-top event-cover-image" src="/images/events/<?php echo e($event->eventPicture); ?>"
                    alt="Card image cap">
                <div class="card-body">

                    <!-- NAME -->
                    <div class="centered-header">
                        <p><?php echo e($event->eventName); ?></p>
                    </div>

                    <!-- DATE -->
                    <div class="row event-row-info">
                        <p><i class="far fa-calendar-alt"></i> Datum</p>
                        <p><?php echo e($event->eventDate); ?></p>
                    </div>

                    <!-- TIME -->
                    <div class="row event-row-info">
                        <p><i class="far fa-clock"></i> Čas</p>
                        <p><?php echo e($event->eventTime); ?></p>
                    </div>

                    <!-- LOCATION -->
                    <div class="row event-row-info">
                        <p><i class="fas fa-map-marker-alt"></i> Lokacija</p>
                        <p><?php echo e($event->eventLocation); ?></p>
                    </div>

                    <!-- TICKET -->
                    <div class="row event-row-info">
                        <p><i class="fas fa-ticket-alt"></i> Vstopnina</p>
                        <p><?php echo e($event->ticketPrice . '€'); ?></p>
                    </div>

                    <div class="row confirm-cancel-container" style="margin-bottom:0px;">
                        <button class="btn btn-primary" onclick="location.href='/uredi-dogodek/<?php echo e($event->id); ?>'">
                            Uredi
                        </button>

                        <button onclick="location.href='/izbrisi-dogodek/<?php echo e($event->id); ?>'" class="btn btn-danger">
                            Izbrisi
                        </button>
                    </div>

                    <!-- DESCRIPTION -->
                    <div class="admin-event-description">
                        <p>OPIS</p>
                        <p><?php echo e($event->eventDescription); ?></p>
                    </div>



                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/events/eventsIndex.blade.php ENDPATH**/ ?>