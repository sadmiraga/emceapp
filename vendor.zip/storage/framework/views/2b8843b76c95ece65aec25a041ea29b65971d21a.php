<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">Nepreštete pijače</h2>
<?php $__env->stopSection(); ?>


<script>
    function activeStocktakingSearch() {
        var query = document.getElementById("search-input-active-stocktaking").value;

        window.location.href = "/active-stocktaking-search/" + query;
    }
</script>


<?php $__env->startSection('content'); ?>

    <!-- ALERT MESSAGES -->
    <?php if (isset($component)) { $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlertComponent::class, []); ?>
<?php $component->withName('alert-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8)): ?>
<?php $component = $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8; ?>
<?php unset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <?php if($started_bool == false): ?>
        <div class="custom-container" id="start-stocklisting">
            <button onclick="location.href='/zacni-popis'" id="zacni-popis-button"
                class="btn btn-success btn-circle btn-sm">Začni Popis</button>
        </div>
    <?php else: ?>



        <!-- SEARCH -->
        <div class="input-group mb-3">

            <!-- reset -->
            <button onclick="location.href='/aktivni-popis'" class="btn btn-warning"><i class="fa fa-close"></i></button>
            <input type="text" id="search-input-active-stocktaking" class="form-control">

            <div class="input-group-append">
                <button onclick="activeStocktakingSearch()" class="btn btn-primary"><i class="fa fa-search"></i></button>
            </div>
        </div>



        <!-- back to top button -->
        <a id="back-to-top-button"></a>

        <div class="drinks-container">

            <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="card drink-card">
                    <div class="drink-header">
                        <?php echo e($drink->drinkName); ?>

                    </div>

                    <div class="card-body drink-body">

                        <!-- KOLICINA -->
                        <?php if(is_null($drink->drinkQuantity)): ?>
                            <div class="drink-quanitity">

                                <div class="name">
                                    <span>Kos</span>
                                </div>

                                <div class="drink-input">
                                    <input type="number" id="quantity-<?php echo e($drink->drinkID); ?>" name="drink-quantity"
                                        class="form-control drink-input-field">
                                </div>

                                <div class="drink-button">
                                    <button onclick="submitQuantity(<?php echo e($drink->drinkID); ?>)" class="btn btn-success">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(is_null($drink->drinkWeight)): ?>
                            <div class="drink-weight">

                                <div class="name">
                                    <span>Teza</span>
                                </div>

                                <div class="drink-input">
                                    <input type="number" step="0.001" id="weight-<?php echo e($drink->drinkID); ?>"
                                        name="drink-weight" class="form-control drink-input-field">
                                </div>

                                <div class="drink-button">
                                    <button onclick="submitWeight(<?php echo e($drink->drinkID); ?>)" class="btn btn-success">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>



    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/bartender/activeStocktaking.blade.php ENDPATH**/ ?>