<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">Zaposleni</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Ime</th>
                    <th scope="col">Priimek</th>
                    <th scope="col">Tip zaposlenega</th>
                    <th scope="col">#</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->id); ?></th>
                        <td><?php echo e($user->firstName); ?></td>
                        <td><?php echo e($user->lastName); ?></td>
                        <td><?php echo e($user->userType); ?></td>
                        <td>


                            <div onclick="location.href='/uredi-zaposleni/<?php echo e($user->id); ?>'" class="add-new-event">
                                <i class="fas fa-cog"></i>
                            </div>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/admin/users.blade.php ENDPATH**/ ?>