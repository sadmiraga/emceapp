<?php $__env->startSection('admin-title'); ?>
    <h2 class="admin-header">Preštete pijače</h2>
<?php $__env->stopSection(); ?>

<script>
    function countedStocktakingSearch() {
        var query = document.getElementById("search-input-counted-stocktaking").value;

        window.location.href = "/counted-stocktaking-search/" + query;
    }
</script>

<?php $__env->startSection('content'); ?>


    <!-- SEARCH -->
    <div class="input-group mb-3">
        <!-- reset -->
        <button onclick="location.href='/prestete-pijace'" class="btn btn-warning"><i class="fa fa-close"></i></button>

        <input type="text" id="search-input-counted-stocktaking" class="form-control">

        <div class="input-group-append">
            <button onclick="countedStocktakingSearch()" class="btn btn-primary"><i class="fa fa-search"></i></button>
        </div>
    </div>

    <!-- ALERT MESSAGES -->
    <?php if (isset($component)) { $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlertComponent::class, []); ?>
<?php $component->withName('alert-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8)): ?>
<?php $component = $__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8; ?>
<?php unset($__componentOriginald02996e44dda3903cba78e7e1216344c6c162fa8); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

    <!-- back to top button -->
    <a id="back-to-top-button"></a>

    <div class="row confirm-cancel-container" style="justify-content:flex-end !important;">

        <button onclick="location.href='/oddaj-popis'" class="btn btn-success">Oddaj popis</button>
    </div>

    <div class="drinks-container">

        <?php $__currentLoopData = $drinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drink): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card drink-card">
                <div class="drink-header">
                    <?php echo e($drink->drinkName); ?>

                </div>

                <div class="card-body drink-body">

                    <!-- KOLICINA -->
                    <?php if(!is_null($drink->drinkQuantity)): ?>
                        <div class="drink-quanitity">

                            <div class="name">
                                <span>Kos: <?php echo e($drink->drinkQuantity); ?></span>
                            </div>

                            <div class="drink-input">
                                <input type="number" id="quantity-<?php echo e($drink->drinkID); ?>" name="drink-quantity"
                                    class="form-control drink-input-field">
                            </div>

                            <div class="drink-button">
                                <button onclick="submitAdditionalQuantity(<?php echo e($drink->drinkID); ?>)" class="btn btn-success">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>



                    <?php if(!is_null($drink->drinkWeight) and $drink->drinkWeight != 0): ?>

                        <div class="drink-weight">

                            <div class="name">
                                <span>Teza: <?php echo e($drink->drinkWeight); ?> kg</span>
                            </div>

                            <div class="drink-input">
                                <input type="number" step="0.001" id="weight-<?php echo e($drink->drinkID); ?>" name="drink-weight"
                                    class="form-control drink-input-field">
                            </div>

                            <div class="drink-button">
                                <button onclick="submitAdditionalWeight(<?php echo e($drink->drinkID); ?>)" class="btn btn-success">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>

                        </div>
                    <?php endif; ?>

                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\vela\Desktop\emce\emceapp\resources\views/bartender/countedStocktaking.blade.php ENDPATH**/ ?>