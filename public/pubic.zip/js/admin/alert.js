
  window.setTimeout(function() {
    $(".alert").slideUp();
}, 3000);


